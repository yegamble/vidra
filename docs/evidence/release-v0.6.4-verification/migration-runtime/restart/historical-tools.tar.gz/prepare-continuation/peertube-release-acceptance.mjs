#!/usr/bin/env node
// Packaged admin UI, real import worker and persisted readback on the retained host.
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';

const [stageArg, mode] = process.argv.slice(2);
assert.ok(stageArg && ['preview', 'import', 'repeat', 'schema-refusal', 'playback'].includes(mode));
assert.equal(process.env.COMPOSE_PROJECT_NAME, 'vidra-release-acceptance');
const stage = resolve(stageArg), baseline = '/root/vidra-v064-runtime';
const output = join(stage, `${mode}-browser.json`);
assert.ok(!existsSync(output), 'preserve old results; use a separate attempt directory');
const result = { status: 'UNVERIFIED', started_at: new Date().toISOString(), mode, checks: {}, requests: [], commands: [] };
const save = () => writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { mode: 0o600 });
const host = args => {
  const record = { argv: args, started_at: new Date().toISOString() }; result.commands.push(record);
  try {
    const text = execFileSync(args[0], args.slice(1), { cwd: '/opt/vidra', encoding: 'utf8', timeout: 60000, stdio: ['ignore', 'pipe', 'pipe'] });
    record.exit_code = 0; return text.trim();
  } catch (error) { record.exit_code = error.status ?? 'TIMEOUT'; throw error; }
};
const sql = query => {
  assert.ok(query.startsWith('SELECT '), 'destination evidence is read only');
  return host(['bash', 'deploy/compose.sh', 'exec', '-T', 'postgres', 'psql', '-U', 'vidra', '-d', 'vidra', '-At', '-v', 'ON_ERROR_STOP=1', '-c', query]);
};
const catalogue = () => Object.fromEntries(['users', 'channels', 'videos', 'comments', 'playlists', 'playlist_items', 'channel_follows', 'video_ratings', 'video_tags', 'video_chapters', 'streaming_playlists'].map(table =>
  [table, Number(sql(`SELECT count(*) FROM ${table}`))]));
let browser, phase = 'login';
try {
  const { chromium, expect } = createRequire(join(baseline, 'browser/package.json'))('@playwright/test');
  result.tool_sha256 = createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');
  result.node = process.version;
  browser = await chromium.launch({ args: ['--host-resolver-rules=MAP secure.video.test 127.0.0.1', '--no-proxy-server', '--autoplay-policy=no-user-gesture-required'] });
  result.browser = browser.version();
  const context = await browser.newContext({ baseURL: 'https://secure.video.test', ignoreHTTPSErrors: true, viewport: { width: 1600, height: 1000 } });
  const page = await context.newPage(); page.setDefaultTimeout(60000);
  const owner = JSON.parse(readFileSync(join(baseline, 'private/owner.json')));
  await page.goto('/login');
  await page.getByLabel('Email or username', { exact: true }).fill(owner.email);
  await page.getByLabel('Password', { exact: true }).fill(owner.password);
  const login = page.waitForResponse(r => r.url().endsWith('/api/v1/auth/login') && r.request().method() === 'POST');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  const response = await login; assert.equal(response.status(), 200);
  let auth = await response.json(); assert.equal(auth.user.role, 'admin');
  await expect(page.getByRole('button', { name: 'Open account menu' })).toBeVisible();
  const api = async (path, method = 'GET', body, token = auth.token) => {
    for (let attempt = 0; attempt < 4; attempt++) {
      const r = await page.evaluate(async ({ path, method, body, token }) => {
        const r = await fetch(path, { method, headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
        return { status: r.status, retry_after: r.headers.get('retry-after'), body: await r.json() };
      }, { path, method, body, token });
      result.requests.push({ path, method, status: r.status, retry_after: r.retry_after }); save();
      if (r.status !== 429) return r;
      const seconds = Number(r.retry_after); assert.ok(seconds > 0 && seconds <= 120);
      await page.waitForTimeout((seconds + 1) * 1000);
    }
    throw new Error('request remained rate limited');
  };
  assert.equal((await api('/api/v1/admin/peertube-import', 'GET', undefined, '')).status, 401);
  assert.equal((await api('/api/v1/admin/peertube-import', 'POST', { mode: 'dry_run' }, '')).status, 401);
  result.checks.anonymous_denied = 'PASS';
  result.catalogue_before = catalogue();

  if (mode !== 'playback') {
    phase = 'launch-through-admin-ui';
    await page.goto('/admin/import-peertube');
    await expect(page.getByRole('heading', { name: 'Import from PeerTube', exact: true })).toBeVisible();
    await page.getByLabel('Media', { exact: true }).selectOption('copy');
    await page.getByLabel('Conflict policy', { exact: true }).selectOption('skip');
    const pending = page.waitForResponse(r => r.url().endsWith('/api/v1/admin/peertube-import') && r.request().method() === 'POST');
    await page.getByRole('button', { name: ['preview', 'schema-refusal'].includes(mode) ? 'Preview (dry run)' : 'Start import', exact: true }).click();
    const launched = await pending; assert.equal(launched.status(), 202);
    const initial = await launched.json(); result.run_id = initial.id;
    assert.equal(initial.media_mode, 'copy'); assert.equal(initial.acknowledged_schema_version, null);
    phase = 'worker-completion';
    let run;
    await expect(async () => {
      const current = await api(`/api/v1/admin/peertube-import/${initial.id}`); assert.equal(current.status, 200);
      run = current.body; assert.ok(['done', 'failed'].includes(run.state));
    }).toPass({ timeout: 600000, intervals: [2000, 4000, 5000] });
    writeFileSync(join(stage, 'private', `${mode}-run.json`), JSON.stringify(run, null, 2), { mode: 0o600 });
    result.run = { id: run.id, state: run.state, mode: run.mode, media_mode: run.media_mode, source_version: run.source_version,
      acknowledged_schema_version: run.acknowledged_schema_version, error_code: run.error_code ?? null,
      entities: run.report?.entities, conflict_count: run.report?.conflicts?.length ?? 0, started_at: run.started_at, finished_at: run.finished_at };
    if (mode === 'schema-refusal') {
      assert.equal(run.state, 'failed'); assert.equal(run.error_code, 'unverified_schema'); assert.equal(run.source_version, 1040);
    } else {
      assert.equal(run.state, 'done'); assert.equal(run.source_version, 970);
      for (const counts of Object.values(run.report.entities)) assert.equal(counts.failed, 0);
      assert.equal(run.report.entities.video_no_media?.imported ?? 0, 0);
      if (mode === 'preview') {
        assert.equal(run.report.entities.video.planned, 7);
        assert.equal(run.report.entities.user.planned, 6);
      }
      if (mode === 'import') assert.equal(run.report.entities.video.imported, 7);
      if (mode === 'repeat') for (const counts of Object.values(run.report.entities)) {
        assert.equal(counts.imported, 0); assert.equal(counts.updated, 0);
      }
    }
    result.catalogue_after = catalogue();
    if (mode !== 'import') assert.deepEqual(result.catalogue_after, result.catalogue_before);
    result.checks[phase] = 'PASS';
    phase = 'persisted-ui-report';
    const refresh = page.waitForResponse(r => r.url().endsWith('/api/v1/auth/refresh'));
    await page.reload(); const rotated = await refresh; assert.equal(rotated.status(), 200); auth = await rotated.json();
    await expect(page.getByRole('region', { name: 'Import run', exact: true })).toBeVisible();
    const readback = await api(`/api/v1/admin/peertube-import/${initial.id}`);
    assert.equal(readback.body.state, run.state); assert.deepEqual(readback.body.report, run.report);
    if (mode === 'schema-refusal') {
      await expect(page.getByRole('button', { name: 'Start import', exact: true })).toBeDisabled();
      await expect(page.getByRole('button', { name: 'Preview (dry run)', exact: true })).toBeDisabled();
    }
    await page.screenshot({ path: join(stage, `${mode}.png`) });
    result.checks[phase] = 'PASS';
  } else {
    phase = 'source-disconnected-playback';
    result.source_running = host(['docker', 'inspect', 'vidra-v064-migration-source-20260911', '--format', '{{.State.Running}}']);
    assert.equal(result.source_running, 'false');
    const mounts = JSON.parse(host(['docker', 'inspect', host(['bash', 'deploy/compose.sh', 'ps', '-q', 'api']), '--format', '{{json .Mounts}}']));
    assert.ok(!mounts.some(m => m.Destination === '/peertube-source'));
    result.source_media_unmounted = true;
    const videos = JSON.parse(sql("SELECT json_agg(v) FROM (SELECT id,title,privacy FROM videos WHERE title LIKE 'Migration fixture %' ORDER BY title) v"));
    result.playback = [];
    for (const item of videos.filter(v => ['Migration fixture progressive', 'Migration fixture hls_only', 'Migration fixture split_audio'].includes(v.title))) {
      await page.goto(`/videos/${item.id}`);
      await expect(page.getByRole('heading', { name: item.title, exact: true })).toBeVisible();
      const video = page.getByTestId('video-player').first().locator('video');
      await expect(async () => assert.ok(await video.evaluate(v => v.readyState >= 2))).toPass({ timeout: 90000 });
      const sample = () => video.evaluate(v => ({ time: v.currentTime, frames: v.getVideoPlaybackQuality().totalVideoFrames,
        audio_bytes: v.webkitAudioDecodedByteCount ?? 0, error: v.error?.message ?? null, muted: v.muted }));
      await video.evaluate(v => { v.pause(); v.currentTime = 0; v.muted = false; });
      const start = await sample(); await video.evaluate(v => v.play());
      let end;
      await expect(async () => { end = await sample(); assert.ok(end.time - start.time >= 2 && end.frames > start.frames && end.audio_bytes > start.audio_bytes); assert.equal(end.error, null); }).toPass({ timeout: 60000 });
      result.playback.push({ id: item.id, title: item.title, start, end }); save();
      await page.screenshot({ path: join(stage, `${item.title.split(' ').at(-1)}.png`) });
    }
    assert.equal(result.playback.length, 3);
    result.checks[phase] = 'PASS';
  }
  result.status = 'PASS';
} catch (error) {
  result.status = 'FAIL'; result.failed_phase = phase;
  writeFileSync(join(stage, 'private', `${mode}-error.txt`), String(error.stack), { mode: 0o600 });
} finally {
  await browser?.close(); result.finished_at = new Date().toISOString(); save();
}
console.log(JSON.stringify({ status: result.status, mode, failed_phase: result.failed_phase }));
process.exitCode = result.status === 'PASS' ? 0 : 1;
